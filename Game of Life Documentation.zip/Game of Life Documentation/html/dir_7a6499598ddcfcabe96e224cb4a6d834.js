var dir_7a6499598ddcfcabe96e224cb4a6d834 =
[
    [ "Game_of_Life", "dir_0c49cf868c731a575fe34d4f0fde5198.html", "dir_0c49cf868c731a575fe34d4f0fde5198" ]
];