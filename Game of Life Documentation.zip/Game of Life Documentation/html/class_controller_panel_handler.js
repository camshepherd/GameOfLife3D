var class_controller_panel_handler =
[
    [ "ControllerPanelHandler", "class_controller_panel_handler.html#a2a558c1333c8b031b47c844d62454c82", null ],
    [ "ControllerPanelHandler", "class_controller_panel_handler.html#ac861a2a09cdf87d14cd75794454e0f0b", null ],
    [ "~ControllerPanelHandler", "class_controller_panel_handler.html#a143ec289f6941fec2f15611262a072e2", null ],
    [ "buildPanel", "class_controller_panel_handler.html#a76de1ad55689abf8d64e2d3f4eb5d318", null ],
    [ "decreaseSpeed", "class_controller_panel_handler.html#a913d25e6804c999698afba05b9545626", null ],
    [ "handleButtonSignal", "class_controller_panel_handler.html#a19c35c2ac067fa0b27828ce0a164e6c3", null ],
    [ "handleEditBoxSignal", "class_controller_panel_handler.html#a26f03b600fcb88c5dd6f71fcae17ac4b", null ],
    [ "handleSliderSignal", "class_controller_panel_handler.html#adb631163b292408bdb87b1b7943e9f72", null ],
    [ "increaseSpeed", "class_controller_panel_handler.html#a04b1140d5519086799303f6b0d6b75ca", null ],
    [ "updatePH", "class_controller_panel_handler.html#ae221d29e4c261c244f2956d166e3be2d", null ]
];