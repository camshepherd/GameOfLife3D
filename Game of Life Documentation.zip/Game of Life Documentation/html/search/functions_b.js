var searchData=
[
  ['panelhandler',['PanelHandler',['../class_panel_handler.html#a66901175cd8883cc20154b7399141395',1,'PanelHandler::PanelHandler()'],['../class_panel_handler.html#abe2d3a5ac2f23a54c9177fc460fb8c26',1,'PanelHandler::PanelHandler(string name, string creator, weak_ptr&lt; queue&lt; SEvent &gt;&gt; _outputQueue, weak_ptr&lt; sf::RenderWindow &gt; _window, weak_ptr&lt; tgui::Gui &gt; _gui)']]],
  ['presetspanelhandler',['PresetsPanelHandler',['../class_presets_panel_handler.html#aff8751f3998266c435dbb00f72dcff01',1,'PresetsPanelHandler::PresetsPanelHandler()'],['../class_presets_panel_handler.html#af3b0ba25ade12410d00e3ee9f4f53374',1,'PresetsPanelHandler::PresetsPanelHandler(string name, string creator, weak_ptr&lt; queue&lt; SEvent &gt;&gt; _outputQueue, FileType fileType, weak_ptr&lt; sf::RenderWindow &gt; _window, weak_ptr&lt; tgui::Gui &gt; _gui)']]]
];
