var searchData=
[
  ['getcell',['getCell',['../class_simulation.html#a3cd0b8fe82bb6c6c9d38c2902574b2a8',1,'Simulation']]],
  ['getedgelength',['getEdgeLength',['../class_simulation.html#ab133346f10af00349c4169d56b79cc97',1,'Simulation']]],
  ['getfilenames',['getFileNames',['../class_file_handler.html#ad0077c3e40285338b05b4fc23f6985d3',1,'FileHandler']]],
  ['getframe',['getFrame',['../class_simulation.html#a6bf7fbfa04cd917cd6925d92d5092aba',1,'Simulation']]],
  ['getnumframes',['getNumFrames',['../class_simulation_handler.html#ad7ebe4109fe6a9c8e9e6dffbc5f226c7',1,'SimulationHandler']]],
  ['getrules',['getRules',['../class_simulation.html#ac03ed96abdb67e61a4dfe63621285522',1,'Simulation::getRules()'],['../class_simulation_handler.html#a3328635a6dc9526f86de09f442ee5066',1,'SimulationHandler::getRules()']]],
  ['getuniversesize',['getUniverseSize',['../class_simulation.html#a29d23e3006ed6d4c8b0e4376eeb28ca0',1,'Simulation']]],
  ['guihandler',['GUIHandler',['../class_g_u_i_handler.html',1,'GUIHandler'],['../class_g_u_i_handler.html#acaf513595443e19e53c60094588389d0',1,'GUIHandler::GUIHandler()'],['../class_g_u_i_handler.html#a0d3391c5f9732f093b40de880571e7d1',1,'GUIHandler::GUIHandler(string name)'],['../class_g_u_i_handler.html#a9997d788a879c27c15f80c44f513e14a',1,'GUIHandler::GUIHandler(string name, string creator, weak_ptr&lt; queue&lt; SEvent &gt;&gt; _outputQueue, weak_ptr&lt; sf::RenderWindow &gt; theWindow)']]]
];
