var searchData=
[
  ['opsuccessfulness',['opSuccessfulness',['../class_file_handler.html#a794ba6874f05aa9f63d0c69da8673d94',1,'FileHandler']]]
];
