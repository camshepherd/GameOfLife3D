var searchData=
[
  ['name',['name',['../class_handler.html#a1039f0add9145da555900abb838ec438',1,'Handler']]],
  ['neighbourqueues',['neighbourQueues',['../class_handler.html#a51107d088acf1d2dd9497c1aa53181f2',1,'Handler']]]
];
