var searchData=
[
  ['clock',['clock',['../class_panel_handler.html#a367088c774facac664e3062380dca789',1,'PanelHandler']]],
  ['closing',['closing',['../class_handler.html#a5b9a155f670ce264d481fe42c7872ac6',1,'Handler']]]
];
