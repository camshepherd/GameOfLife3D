var searchData=
[
  ['operationstate',['operationState',['../struct_s_event.html#a4edc856282b867e3e3b1c8cc71241cf7',1,'SEvent']]]
];
