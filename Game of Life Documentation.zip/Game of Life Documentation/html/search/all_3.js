var searchData=
[
  ['changerule',['changeRule',['../class_simulation.html#a099f4331a149b5bf431d453d645016d2',1,'Simulation::changeRule(string rule, int newVal)'],['../class_simulation.html#a34fbda5a3e8cc60ff3129d8dd46d497c',1,'Simulation::changeRule(weak_ptr&lt; Rule &gt; newRules)']]],
  ['changestate',['changeState',['../class_g_u_i_handler.html#a6a3a51afd51ff3c6130470c5d480299d',1,'GUIHandler']]],
  ['clock',['clock',['../class_panel_handler.html#a367088c774facac664e3062380dca789',1,'PanelHandler']]],
  ['closing',['closing',['../class_handler.html#a5b9a155f670ce264d481fe42c7872ac6',1,'Handler']]],
  ['controllerpanelhandler',['ControllerPanelHandler',['../class_controller_panel_handler.html',1,'ControllerPanelHandler'],['../class_controller_panel_handler.html#a2a558c1333c8b031b47c844d62454c82',1,'ControllerPanelHandler::ControllerPanelHandler()'],['../class_controller_panel_handler.html#ac861a2a09cdf87d14cd75794454e0f0b',1,'ControllerPanelHandler::ControllerPanelHandler(string name, string creator, weak_ptr&lt; queue&lt; SEvent &gt;&gt; _outputQueue, weak_ptr&lt; sf::RenderWindow &gt; _window, weak_ptr&lt; tgui::Gui &gt; _gui)']]],
  ['countneighbours',['countNeighbours',['../class_simulation.html#a2b8aabc4bd675d802eb1589c583adb0d',1,'Simulation']]]
];
