var searchData=
[
  ['adddonotforward',['addDoNotForward',['../class_handler.html#a3166667d5f2f5469e7a711d9f3ff0edc',1,'Handler']]],
  ['applydefaultcolor',['applyDefaultColor',['../class_panel_handler.html#a379a80647f4950d732ced3276462343c',1,'PanelHandler']]]
];
