var searchData=
[
  ['savefile',['saveFile',['../class_file_handler.html#abf1e200286b01ec5dd62b582d4ed227b',1,'FileHandler']]],
  ['sctype',['Sctype',['../class_sctype.html',1,'']]],
  ['sender',['sender',['../struct_s_event.html#a542c2cdb34c425a290f0a48111a9aa76',1,'SEvent']]],
  ['sendmessage',['sendMessage',['../class_handler.html#ade66d7837b14f6fd7064609cd0bf3360',1,'Handler']]],
  ['setcell',['setCell',['../class_simulation.html#adebcb7b87a66bbe1c34611a7ae632bd9',1,'Simulation']]],
  ['setdefaultcolor',['setDefaultColor',['../class_panel_handler.html#ad0479943902ed7e6c7122ab07906a4a9',1,'PanelHandler']]],
  ['setedgelength',['setEdgeLength',['../class_simulation.html#acc1e02ae079c8f7bec73e17872cb96ed',1,'Simulation']]],
  ['setgui',['setGui',['../class_panel_handler.html#aa1826ac932d64e251f4b15a71a80774c',1,'PanelHandler']]],
  ['setname',['setName',['../class_handler.html#afac431e0fb4c5bf740976c0e8f2cd1d3',1,'Handler']]],
  ['setneighbour',['setNeighbour',['../class_handler.html#aa4d855926599c897a95114999a1e5040',1,'Handler']]],
  ['setstate',['setState',['../class_panel_handler.html#a1485351b8e8612ebe2ad874c8a2bbd5d',1,'PanelHandler']]],
  ['settodefault',['setToDefault',['../class_g_u_i_handler.html#a392945751a67bc45923857a793b24c43',1,'GUIHandler']]],
  ['setwindow',['setWindow',['../class_input_handler.html#acb3479170508e2320d833e308d1d0032',1,'InputHandler::setWindow()'],['../class_panel_handler.html#aaff1360a5cc837c93b9538328dfa08b4',1,'PanelHandler::setWindow()']]],
  ['sevent',['SEvent',['../struct_s_event.html',1,'SEvent'],['../struct_s_event.html#a2e60d199379c1d40666d14b94a978e41',1,'SEvent::SEvent()']]],
  ['simulatetoframe',['simulateToFrame',['../class_simulation.html#a1ea88e0af6b945b36484dafb0bba11dc',1,'Simulation']]],
  ['simulation',['Simulation',['../class_simulation.html',1,'Simulation'],['../class_simulation.html#a5b224cc5b36bcc8eb29689aff223de41',1,'Simulation::Simulation()'],['../class_simulation.html#acdedd31f0311b2ed569c71cf1a698791',1,'Simulation::Simulation(int edgeLength)'],['../class_simulation.html#a1205268954c6dd943ff7ca5e4b969be8',1,'Simulation::Simulation(weak_ptr&lt; vector&lt; vector&lt; vector&lt; int &gt;&gt;&gt;&gt; startFrame, int edgeLength)'],['../class_simulation.html#a2631ff9ae32fe73af70d880ab7a3f4ea',1,'Simulation::Simulation(string stringForm)']]],
  ['simulationhandler',['SimulationHandler',['../class_simulation_handler.html',1,'SimulationHandler'],['../class_simulation_handler.html#a065e723fb46bef0d7049a56861bece69',1,'SimulationHandler::SimulationHandler()'],['../class_simulation_handler.html#a29c94b71efa2a4e2077fdec44fd661fe',1,'SimulationHandler::SimulationHandler(string name, string creator, weak_ptr&lt; queue&lt; SEvent &gt;&gt; _outputQueue)']]],
  ['state',['state',['../class_g_u_i_handler.html#a27007c2b95381b736fbb7a6e7b51fe06',1,'GUIHandler::state()'],['../class_panel_handler.html#abe286ca4bf4cd475f8925da86a8b9518',1,'PanelHandler::state()']]],
  ['step',['step',['../class_simulation.html#aaf64cc6f1c18ad7377e452d6b35cbb96',1,'Simulation']]],
  ['str1',['str1',['../struct_s_event.html#a7ff886919645fb8c6f5dd32407b57d3a',1,'SEvent']]],
  ['stream',['stream',['../struct_s_event.html#a55963be5e272de8d13207a70990de98a',1,'SEvent']]]
];
