var class_menu_panel_handler =
[
    [ "MenuPanelHandler", "class_menu_panel_handler.html#a30555b283bbb5829bdb55aa8791d67b4", null ],
    [ "MenuPanelHandler", "class_menu_panel_handler.html#ac8ebb44b7f830f29a5e5f151294199fd", null ],
    [ "~MenuPanelHandler", "class_menu_panel_handler.html#ab5484bd69402229cec6e01bbec635892", null ],
    [ "buildPanel", "class_menu_panel_handler.html#a6d24682d42bcb7637892ca8cb6667a44", null ],
    [ "updatePH", "class_menu_panel_handler.html#a1836ea117352d2039fed9a091f1530f4", null ]
];