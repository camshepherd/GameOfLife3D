var struct_packed_vertex =
[
    [ "operator<", "struct_packed_vertex.html#a55d44e50175d12af6a9ca3eb1a8f8845", null ],
    [ "normal", "struct_packed_vertex.html#a1e1099f55d9c2837da6d579c3bb6a633", null ],
    [ "position", "struct_packed_vertex.html#a5ef57f8f17bfb8a6f5014a943eacecc9", null ],
    [ "uv", "struct_packed_vertex.html#a1fd4c6774f04d72651423ca054ae5b26", null ]
];