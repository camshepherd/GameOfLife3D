var class_presets_panel_handler =
[
    [ "PresetsPanelHandler", "class_presets_panel_handler.html#aff8751f3998266c435dbb00f72dcff01", null ],
    [ "PresetsPanelHandler", "class_presets_panel_handler.html#af3b0ba25ade12410d00e3ee9f4f53374", null ],
    [ "~PresetsPanelHandler", "class_presets_panel_handler.html#aaf314a1894f813cde4bd7329b7973332", null ],
    [ "buildPanel", "class_presets_panel_handler.html#a89f38a9513a2722a3bb8048ed63e7548", null ],
    [ "updatePH", "class_presets_panel_handler.html#abc50d32727bbcf0c1614b64d4af63671", null ]
];