var class_sctype =
[
    [ "Sctype", "class_sctype.html#a79e841e705392c8ecd1dca9de54e9ef3", null ]
];